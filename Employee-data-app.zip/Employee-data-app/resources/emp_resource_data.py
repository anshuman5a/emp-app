from flask_restful import Resource
from flask import request
import json

employees = [
    {"id": 1, "name": "Aman", "age": 40, "department": "IT"},
    {"id": 2, "name": "Raj", "age": 30, "department": "HR"}
]

class EmployeesGETResource(Resource):
    def get(self):
        return employees

class EmployeeGETResource(Resource):
    def get(self, id):
        for employee in employees:
            if employee["id"] == id:
                return employee
        return {"message": "Employee not found"}, 404

class EmployeePOSTResource(Resource):
    def post(self):
        employee = json.loads(request.data)
        new_id = max(emp["id"] for emp in employees) + 1
        employee["id"] = new_id
        employees.append(employee)
        return employee, 201

class EmployeePUTResource(Resource):
    def put(self, id):
        employee = json.loads(request.data)
        for _employee in employees:
            if _employee["id"] == id:
                _employee.update(employee)
                return _employee
        return {"message": "Employee not found"}, 404

class EmployeeDELETEResource(Resource):
    def delete(self, id):
        global employees
        employees = [employee for employee in employees if employee["id"] != id]
        return "", 204
